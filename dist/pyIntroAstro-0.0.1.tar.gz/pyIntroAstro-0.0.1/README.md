Python package for teaching Introduction to Astrophysics by James Aguirre.
